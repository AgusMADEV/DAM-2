archivo = open("clientes.bin",'wb')

archivo.write(b"soy un cliente")

archivo.close()
