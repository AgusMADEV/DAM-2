1. Desarrolla aplicaciones que gestionan información almacenada en ficheros identificando el campo de aplicación de los mismos y utilizando clases específicas.

Criterios de evaluación:

a) Se han utilizado clases para la gestión de ficheros y directorios.

b) Se han valorado las ventajas y los inconvenientes de las distintas formas de acceso.

c) Se han utilizado clases para recuperar información almacenada en ficheros.

d) Se han utilizado clases para almacenar información en ficheros.

e) Se han utilizado clases para realizar conversiones entre diferentes formatos de ficheros.

f) Se han previsto y gestionado las excepciones.

g) Se han probado y documentado las aplicaciones desarrolladas.
