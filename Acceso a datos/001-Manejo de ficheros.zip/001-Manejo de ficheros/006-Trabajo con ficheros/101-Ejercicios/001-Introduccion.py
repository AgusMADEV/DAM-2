Vamos a hacer un simulacro de conector a csv

clientes
nombre,apellidos,email,direccion
Jose Vicente,Carratala,info@jocarsa.com,La calle de Jose Vicente

